#Está linha verde é um comentário!!!
#para imprimir alguma coisa no terminal, digite o comando "print".

print("Olá mundo!")